#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void matmul_64_incore_1(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3) {
  const int64_t v4 = 64;
  const int64_t v5 = 16384;
  const int64_t v6 = 0;
  using T = float;

  #if defined(__DAV_CUBE__)
  // pto: %tile_a_l1__ssa_v0
  Tile<TileType::Mat, float, 64, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v7 = Tile<TileType::Mat, float, 64, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v4, v4);
  // pto: %tile_a_l1__ssa_v0
  uint64_t v8 = (uint64_t) v6;
  TASSIGN(v7, v8);
  // pto: %a1__ssa_v0_pview
  pto::Shape<1, 1, 1, 64, 64> v9 = pto::Shape<1, 1, 1, 64, 64>();
  // pto: %a1__ssa_v0_pview
  pto::Stride<4096, 4096, 4096, 64, 1> v10 = pto::Stride<4096, 4096, 4096, 64, 1>();
  // pto: %a1__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 64, 64>, pto::Stride<4096, 4096, 4096, 64, 1>, pto::Layout::ND> v11 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 64>, pto::Stride<4096, 4096, 4096, 64, 1>, pto::Layout::ND>(v1, v9, v10);
  TLOAD(v7, v11);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  // pto: %tile_b_l1__ssa_v0
  Tile<TileType::Mat, float, 64, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v12 = Tile<TileType::Mat, float, 64, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v4, v4);
  // pto: %tile_b_l1__ssa_v0
  uint64_t v13 = (uint64_t) v5;
  TASSIGN(v12, v13);
  // pto: %b1__ssa_v0_pview
  pto::Shape<1, 1, 1, 64, 64> v14 = pto::Shape<1, 1, 1, 64, 64>();
  // pto: %b1__ssa_v0_pview
  pto::Stride<4096, 4096, 4096, 64, 1> v15 = pto::Stride<4096, 4096, 4096, 64, 1>();
  // pto: %b1__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 64, 64>, pto::Stride<4096, 4096, 4096, 64, 1>, pto::Layout::ND> v16 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 64>, pto::Stride<4096, 4096, 4096, 64, 1>, pto::Layout::ND>(v2, v14, v15);
  TLOAD(v12, v16);
  set_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  // pto: %tile_a_l0a__ssa_v0
  Tile<TileType::Left, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null> v17 = Tile<TileType::Left, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::RowMajor, 512, PadValue::Null, CompactMode::Null>(v4, v4);
  // pto: %tile_a_l0a__ssa_v0
  uint64_t v18 = (uint64_t) v6;
  TASSIGN(v17, v18);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID0);
  TMOV(v17, v7);
  // pto: %tile_b_l0b__ssa_v0
  Tile<TileType::Right, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null> v19 = Tile<TileType::Right, float, 64, 64, BLayout::RowMajor, -1, -1, SLayout::ColMajor, 512, PadValue::Null, CompactMode::Null>(v4, v4);
  // pto: %tile_b_l0b__ssa_v0
  uint64_t v20 = (uint64_t) v6;
  TASSIGN(v19, v20);
  wait_flag(PIPE_MTE2, PIPE_MTE1, EVENT_ID1);
  TMOV(v19, v12);
  set_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  // pto: %tile_c_l0c__ssa_v0
  Tile<TileType::Acc, float, 64, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null> v21 = Tile<TileType::Acc, float, 64, 64, BLayout::ColMajor, -1, -1, SLayout::RowMajor, 1024, PadValue::Null, CompactMode::Null>(v4, v4);
  // pto: %tile_c_l0c__ssa_v0
  uint64_t v22 = (uint64_t) v6;
  TASSIGN(v21, v22);
  wait_flag(PIPE_MTE1, PIPE_M, EVENT_ID0);
  TMATMUL(v21, v17, v19);
  set_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  // pto: %c__ssa_v0_pview
  pto::Shape<1, 1, 1, 64, 64> v23 = pto::Shape<1, 1, 1, 64, 64>();
  // pto: %c__ssa_v0_pview
  pto::Stride<4096, 4096, 4096, 64, 1> v24 = pto::Stride<4096, 4096, 4096, 64, 1>();
  // pto: %c__ssa_v0_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 64, 64>, pto::Stride<4096, 4096, 4096, 64, 1>, pto::Layout::ND> v25 = GlobalTensor<float, pto::Shape<1, 1, 1, 64, 64>, pto::Stride<4096, 4096, 4096, 64, 1>, pto::Layout::ND>(v3, v23, v24);
  wait_flag(PIPE_M, PIPE_FIX, EVENT_ID0);
  TSTORE(v25, v21);
  #endif // __DAV_CUBE__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}