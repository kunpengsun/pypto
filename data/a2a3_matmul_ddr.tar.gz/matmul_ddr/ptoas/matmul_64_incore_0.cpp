#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void matmul_64_incore_0(__gm__ float* v1, __gm__ float* v2, __gm__ float* v3, __gm__ float* v4) {
  const int64_t v5 = 1;
  const int64_t v6 = 64;
  const int64_t v7 = 0;
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  for (int64_t i8 = v7; i8 < v6; i8 += v5) {
    // pto: %copy_chunk
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v9 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
    // pto: %copy_chunk
    uint64_t v10 = (uint64_t) v7;
    TASSIGN(v9, v10);
    // pto: %1
    int64_t v11 = i8 < v7 ? v7 : i8;
    // pto: %a__ssa_v0_pview
    pto::Shape<1, 1, 1, 1, 64> v12 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %a__ssa_v0_pview
    pto::Stride<64, 64, 64, 64, 1> v13 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %a__ssa_v0_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v14 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v2 + (v7 + v11 * v6), v12, v13);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
    TLOAD(v9, v14);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    // pto: %copy_dst_pview
    pto::Shape<1, 1, 1, 1, 64> v15 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %copy_dst_pview
    pto::Stride<64, 64, 64, 64, 1> v16 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %copy_dst_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v17 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v1 + (v7 + v11 * v6), v15, v16);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID0);
    TSTORE(v17, v9);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  }
  set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID1);
  for (int64_t i18 = v7; i18 < v6; i18 += v5) {
    // pto: %0
    Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null> v19 = Tile<TileType::Vec, float, 1, 64, BLayout::RowMajor, -1, -1, SLayout::NoneBox, 512, PadValue::Null, CompactMode::Null>(v5, v6);
    // pto: %0
    uint64_t v20 = (uint64_t) v7;
    TASSIGN(v19, v20);
    // pto: %4
    int64_t v21 = i18 < v7 ? v7 : i18;
    // pto: %b__ssa_v0_pview
    pto::Shape<1, 1, 1, 1, 64> v22 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %b__ssa_v0_pview
    pto::Stride<64, 64, 64, 64, 1> v23 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %b__ssa_v0_pview
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v24 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v4 + (v7 + v21 * v6), v22, v23);
    wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
    TLOAD(v19, v24);
    set_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
    // pto: %7
    pto::Shape<1, 1, 1, 1, 64> v25 = pto::Shape<1, 1, 1, 1, 64>();
    // pto: %7
    pto::Stride<64, 64, 64, 64, 1> v26 = pto::Stride<64, 64, 64, 64, 1>();
    // pto: %7
    GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND> v27 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 64>, pto::Stride<64, 64, 64, 64, 1>, pto::Layout::ND>(v3 + (v7 + v21 * v6), v25, v26);
    wait_flag(PIPE_MTE2, PIPE_MTE3, EVENT_ID1);
    TSTORE(v27, v19);
    set_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  }
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID0);
  wait_flag(PIPE_MTE3, PIPE_MTE2, EVENT_ID2);
  #endif // __DAV_VEC__

  ptoas_auto_sync_tail(PTOAutoSyncTailMode::kBarrierAll);
  return;
}