#include "pto/pto-inst.hpp"
using namespace pto;

template <typename Tensor>
static AICORE inline auto PTOAS__GLOBAL_TENSOR_DATA(Tensor &tensor)
    -> decltype(tensor.data()) {
  return tensor.data();
}


enum class PTOAutoSyncTailMode : int {
  kBarrierAll = 0,
  kSetWaitMte3ToSEvent0 = 1,
};

static AICORE inline void ptoas_auto_sync_tail(
    PTOAutoSyncTailMode mode = PTOAutoSyncTailMode::kBarrierAll) {
  switch (mode) {
  case PTOAutoSyncTailMode::kSetWaitMte3ToSEvent0:
    set_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    wait_flag(PIPE_MTE3, PIPE_S, EVENT_ID0);
    break;
  case PTOAutoSyncTailMode::kBarrierAll:
  default:
    pipe_barrier(PIPE_ALL);
    break;
  }
}

template <typename Ptr>
static AICORE inline void PTOAS__DCCI_SINGLE_CACHE_LINE(Ptr ptr) {
  dcci((__gm__ void*)ptr, cache_line_t::SINGLE_CACHE_LINE);
}

AICORE void matmul_64_incore_0(__gm__ float* v1, __gm__ float* v2, __gm__ int8_t* v3) {
  using T = float;

  #if defined(__DAV_VEC__)
  set_mask_norm();
  set_vector_mask(-1, -1);
  // pto: %copy_prefetch_ctx__ssa_v0
  __gm__ uint8_t* v4 = reinterpret_cast<__gm__ uint8_t*>(v3);
  // pto: %copy_prefetch_ctx__ssa_v0
  pto::PrefetchAsyncContext v5 = pto::PrefetchAsyncContext(v4);
  // pto: %a1__ssa_v1_pview
  pto::Shape<1, 1, 1, 1, 4096> v6 = pto::Shape<1, 1, 1, 1, 4096>();
  // pto: %a1__ssa_v1_pview
  pto::Stride<4096, 4096, 4096, 4096, 1> v7 = pto::Stride<4096, 4096, 4096, 4096, 1>();
  // pto: %a1__ssa_v1_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v8 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v1, v6, v7);
  // pto: %copy_prefetch_evt__ssa_v0
  pto::comm::AsyncEvent v9 = TPREFETCH_ASYNC(v8, v5);
  // pto: %copy_prefetch_session__ssa_v0
  pto::comm::AsyncSession v10 = v5.session;
  // pto: %1
  bool v11 = v9.Wait(v10);
  // pto: %2
  __gm__ uint8_t* v12 = reinterpret_cast<__gm__ uint8_t*>(v3);
  // pto: %2
  pto::PrefetchAsyncContext v13 = pto::PrefetchAsyncContext(v12);
  // pto: %b1__ssa_v1_pview
  pto::Shape<1, 1, 1, 1, 4096> v14 = pto::Shape<1, 1, 1, 1, 4096>();
  // pto: %b1__ssa_v1_pview
  pto::Stride<4096, 4096, 4096, 4096, 1> v15 = pto::Stride<4096, 4096, 4096, 4096, 1>();
  // pto: %b1__ssa_v1_pview
  GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND> v16 = GlobalTensor<float, pto::Shape<1, 1, 1, 1, 4096>, pto::Stride<4096, 4096, 4096, 4096, 1>, pto::Layout::ND>(v2, v14, v15);
  // pto: %3
  pto::comm::AsyncEvent v17 = TPREFETCH_ASYNC(v16, v13);
  // pto: %5
  pto::comm::AsyncSession v18 = v13.session;
  // pto: %6
  bool v19 = v17.Wait(v18);
  #endif // __DAV_VEC__

  return;
}